packs - the game data
=====================

palette.zpl and zod_engine.zpk come with the engine. The rest (graphics,
sounds, loading screens) is written here by ZExtract from your CD of "Z":

  CD Work:Games/ZOD
  ZExtract CD0:

See doc/Install.txt.

-----------------------------------------------------------------------

packs - dane gry

palette.zpl i zod_engine.zpk sa dostarczane z silnikiem. Reszte (grafike,
dzwieki, ekrany ladowania) zapisuje tu ZExtract z Twojej plyty "Z" -
zobacz doc/Install.txt.

-----------------------------------------------------------------------

packs - die Spieldaten

palette.zpl und zod_engine.zpk geh�ren zur Engine. Den Rest (Grafik,
Kl�nge, Ladebilder) schreibt ZExtract von Ihrer CD von "Z" hierher -
siehe doc/Install.txt.
